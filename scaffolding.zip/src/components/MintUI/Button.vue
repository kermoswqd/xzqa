<template>
  <div>
    <mt-button type="default">默认</mt-button>
    <mt-button type="primary">主要</mt-button>
    <mt-button type="danger">危险</mt-button>
    <mt-button type="primary" size="small">小的</mt-button>
    <mt-button type="primary" size="normal">标准</mt-button>
    <mt-button type="primary" size="large">大的</mt-button>
    <mt-button type="primary" size="large" plain>镂空</mt-button>
    <mt-button icon="back" type="primary"></mt-button>
    <mt-button icon="more" type="primary"></mt-button>
  </div>
</template>